const { GetAllActiveOrders } = require("../models/index");
const Web3 = require("web3");
const {
  sendSignedTransaction,
  getPublicKey,
  getCurrentGasPrices,
  getCurrentGasMultiplier,
} = require("../helpers");
require("dotenv").config();
const { routerAbi } = require("../abi/router");
const { swapTokenAbi, swapAbi } = require("../abi/swap");

//mainnet config
let config = {
  transactionStatus: true,
  parentAddress: null,
  web3: null,

  rpcUrl: process.env.RPC_URL,
  privateKey: process.env.PRIVATE_KEY,
  childAddress: process.env.CHILD_ADDRESS,
  gasLimit: process.env.GAS_LIMIT,
  //low, medium, fast
  gasMode: process.env.GAS_MODE,
  gasMultiplier: process.env.GAS_MULTIPLIER,
  // mainnet
  // weth: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2",

  // rinkeby
  weth: "0xc778417E063141139Fce010982780140Aa0cD5Ab",
  swapContractAddress: "0xD525a83d2fAb940561F1335B3a376FD28e44fdd5",
  factory: "0x5c69bee701ef814a2b6a3edd4b1652cb9cc5aa6f", //uniswap factory
  routerAddress: "0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D",
  routerAbi: routerAbi,
  swapAbi: swapAbi,
  routerContract: null,
  swapContract: null,

  deadLine: 5,
};

const loadWeb3 = async () => {
  try {
    const web3 = new Web3(config.rpcUrl);
    config.web3 = web3;
    const parentAddress = await getPublicKey(web3, config.privateKey);
    config.parentAddress = parentAddress;

    const routerContract = new web3.eth.Contract(
      config.routerAbi,
      config.routerAddress
    );
    const swapContract = new web3.eth.Contract(
      config.swapAbi,
      config.swapContractAddress
    );
    config.routerContract = routerContract;
    config.swapContract = swapContract;

    return config;
  } catch (error) {
    console.log("error", error);
  }
};

const eventWatcher = async () => {
  try {
    const web3 = config.web3;
    const routerContract = config.routerContract;
    const swapContract = config.swapContract;
    // console.log("swap contract", swapContract)
    const wethAddress = config.weth.toLowerCase();
    // const deadLine = config.deadLine;
    let recipientAddress;
    if (web3) {
      config.transactionStatus = false;
      let gasPrice = await web3.eth.getGasPrice();
      gasPrice = (
        Number(gasPrice) * getCurrentGasMultiplier(config.gasMode)
      ).toFixed(0);
      let orders = await GetAllActiveOrders();
      console.log("gasPrice", gasPrice);
      orders = orders.map(async (item) => {
        let ethAmount = (item.ethAmount * 10 ** 18).toFixed(0);
        let tokenAmount = (item.tokenAmount * 10 ** item.decimals).toFixed(0);

        if (item.type === "Sell") {
          let data = await swapContract.methods
            .swapSellToken(
              config.routerAddress,
              item.tokenAddress,
              wethAddress,
              item.userAdddress,
              tokenAmount, //amount out
              ethAmount // amount in
            )
            .encodeABI();
          let receipt = await sendSignedTransaction(
            web3,
            config.swapContractAddress,
            config.privateKey,
            gasPrice,
            data
          );
          console.log("receipt", receipt, receipt.status);
        }
        // const amountOutMin = 1;
        // if (item.type === "Buy") {
        //   let data = await routerContract.methods
        //   .swapExactETHForTokensSupportingFeeOnTransferTokens(
        //     tokenAmount,
        //     [wethAddress, item.tokenAddress],
        //     item.userAdddress,
        //     Date.now() + 1000 * 60 * deadline
        //   )
        //   .encodeABI();
        //  let receipt =  await sendSignedTransaction(
        //     web3,
        //     config.router,
        //     config.privateKey,
        //     gasPrice,
        //     data,
        //     ethAmount
        //   );
        // }
      });
    }
    config.transactionStatus = true;
  } catch (error) {
    config.transactionStatus = true;

    console.log("error", error);
  }
};

module.exports = {
  loadWeb3,
  config,
  eventWatcher,
};
